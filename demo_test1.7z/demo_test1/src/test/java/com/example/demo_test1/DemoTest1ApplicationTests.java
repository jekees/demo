package com.example.demo_test1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTest1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
