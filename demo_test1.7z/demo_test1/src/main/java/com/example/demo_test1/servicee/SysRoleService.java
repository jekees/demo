package com.example.demo_test1.servicee;

import com.baomidou.mybatisplus.extension.service.IService;

import com.example.demo_test1.model.system.SysRole;
import com.example.demo_test1.model.system.SysUser;
import com.example.demo_test1.model.vo.AssginRoleVo;
import org.springframework.stereotype.Component;


import java.util.Map;
@Component
public interface SysRoleService extends IService<SysRole> {

    Map<String, Object> getRoleMapsByUserId(String id);

    void doAssign(AssginRoleVo assginRoleVo);
}
