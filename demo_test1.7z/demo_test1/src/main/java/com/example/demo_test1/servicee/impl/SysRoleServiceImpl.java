package com.example.demo_test1.servicee.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.example.demo_test1.mapper.SysRoleMapper;
import com.example.demo_test1.mapper.SysUser_RoleMapper;
import com.example.demo_test1.model.system.SysRole;
import com.example.demo_test1.model.system.SysUserRole;
import com.example.demo_test1.model.vo.AssginRoleVo;
import com.example.demo_test1.servicee.SysRoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SysRoleServiceImpl extends ServiceImpl<SysRoleMapper, SysRole> implements SysRoleService {

    @Autowired
    private SysUser_RoleMapper sysUserRoleMapper;

    @Override
    public Map<String, Object> getRoleMapsByUserId(String id) {
        List<SysRole> roles = baseMapper.selectList(null);
        QueryWrapper<SysUserRole> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_id",id);
        List<SysUserRole> userRoles = sysUserRoleMapper.selectList(queryWrapper);
        List<String> userRoleIds =new ArrayList<>();
        userRoles.forEach(i->{userRoleIds.add(i.getRoleId());});
        Map<String,Object>  map=new HashMap<>();
        map.put("allRoles",roles);
        map.put("userRoleIds",userRoleIds);
        return map;
    }

    @Override
    public void doAssign(AssginRoleVo assginRoleVo) {
        //先删除用户角色信息
        QueryWrapper<SysUserRole> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("user_id",assginRoleVo.getUserId());
        sysUserRoleMapper.delete(queryWrapper);
        //重新添加
        List<String> roleIdList = assginRoleVo.getRoleIdList();
        roleIdList.forEach(i->{
            SysUserRole sysUserRole=new SysUserRole();
            sysUserRole.setRoleId(i);
            sysUserRole.setUserId(assginRoleVo.getUserId());
            sysUserRoleMapper.insert(sysUserRole);
        });
    }


}
