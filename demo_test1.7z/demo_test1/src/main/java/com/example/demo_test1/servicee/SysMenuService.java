package com.example.demo_test1.servicee;


import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo_test1.model.system.SysMenu;
import com.example.demo_test1.model.vo.AssginMenuVo;
import com.example.demo_test1.model.vo.AssginRoleVo;
import com.example.demo_test1.model.vo.RouterVo;
import org.springframework.stereotype.Component;

import java.util.List;

/**
* @author gys
* @description 针对表【sys_menu(菜单表)】的数据库操作Service
* @createDate 2023-05-06 13:56:08
*/
@Component
public interface SysMenuService extends IService<SysMenu> {

    List<SysMenu> findNodes();

    boolean removeMenuById(long id);

    List<SysMenu> getMenuByRoleId(String id);

    boolean toAssign(AssginMenuVo assginRoleVo);

    List<String> getUserButtonList(String id);

    List<RouterVo> getUserMenuList(String id);
}
