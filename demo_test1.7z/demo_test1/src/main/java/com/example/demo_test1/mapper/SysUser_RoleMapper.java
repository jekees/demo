package com.example.demo_test1.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo_test1.model.system.SysRole;
import com.example.demo_test1.model.system.SysUserRole;
import com.example.demo_test1.model.vo.SysRoleQueryVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

@Mapper
public interface SysUser_RoleMapper extends BaseMapper<SysUserRole> {

}