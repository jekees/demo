package com.example.demo_test1.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo_test1.mapper.SysUserMapper;
import com.example.demo_test1.model.base.Result;
import com.example.demo_test1.model.system.SysUser;
import com.example.demo_test1.model.vo.SysUserQueryVo;
import com.example.demo_test1.servicee.SysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@Api(tags = "用户管理接口 ")
@RestController
@RequestMapping("/admin/system/sysUser")
public class SysUserController {

    private SysUserService sysUserService;
    private SysUserMapper sysUserMapper;


    @Autowired
    public SysUserController(SysUserService sysUserService, SysUserMapper sysUserMapper){
        this.sysUserService=sysUserService;
        this.sysUserMapper=sysUserMapper;
    }
//
//    @ApiOperation("获取全部")
//    @GetMapping("/findAll")
//    public Result findAllRole(){
//        List<SysRole> list = sysUserService.list();
//        return Result.ok(list);
//    }
//
    @PreAuthorize("hasAuthority('bnt.sysUser.remove')")
    @ApiOperation("根据id逻辑删除")
    @DeleteMapping("/remove/{id}")
    public Result removeRoleById(@PathVariable("id") long id){
        boolean b = sysUserService.removeById(id);
        if(b){
            return Result.ok();
        }
        else {
            return Result.fail();
        }

    }
//
    @PreAuthorize("hasAuthority('bnt.sysUser.list')")
    @ApiOperation("条件分页查询")
    @GetMapping("/{page}/{limit}")
    public Result findPageQueryUser(@PathVariable("page") Long page, @PathVariable("limit") Long limit, SysUserQueryVo sysUserQueryVo){
        Page<SysUser> page1=new Page<>(page,limit);
        IPage<SysUser> pageModel=sysUserMapper.selectPage(page1,sysUserQueryVo);
        return Result.ok(pageModel);
    }
//
    @PreAuthorize("hasAuthority('bnt.sysUser.add')")
    @ApiOperation("添加用户")
    @PostMapping("/save")
    public Result saveRole(@RequestBody SysUser user){


        user.setPassword(user.getPassword());
        boolean is_Success = sysUserService.save(user);
        if(is_Success) {
            return Result.ok();
        } else {
            return Result.fail();
        }
    }
//
//
    @PreAuthorize("hasAuthority('bnt.sysUser.update')")
    @ApiOperation("根据id修改")
    @PutMapping("/updateStatusById/{id}/{status}")
    public Result updateStatusById(@PathVariable("id") long id,@PathVariable("status") Integer status){
        SysUser sysUser=(SysUser)findUserByID(id).getData();
        sysUser.setStatus(status);
        boolean b = sysUserService.updateById(sysUser);
        if(b){
            return Result.ok();
        }
        else {
            return Result.fail();
        }
    }
//

    @PreAuthorize("hasAuthority('bnt.sysUser.update')")
    @ApiOperation("狀態管理")
    @PutMapping("/updateById")
    public Result updateRoleByID(@RequestBody SysUser user){

        boolean b = sysUserService.updateById(user);
        if(b){
            return Result.ok();
        }
        else {
            return Result.fail();
        }
    }

    @PreAuthorize("hasAuthority('bnt.sysUser.list')")
    @ApiOperation("根据id查询")
    @GetMapping("/findById/{id}")
    public Result findUserByID(@PathVariable long  id){

        SysUser b = sysUserService.getById(id);
        if(b!=null){
            return Result.ok(b);
        }
        else {
            return Result.fail();
        }
    }
//
//    @ApiOperation("根据id批量删除")
//    @DeleteMapping("/removeByIds")
//    public Result removeRolesByID(@RequestBody List<Long> ids){
//        List list=new ArrayList();
//        boolean b = sysRoleService.removeBatchByIds(ids);;
//        return Result.ok();
//    }

}
