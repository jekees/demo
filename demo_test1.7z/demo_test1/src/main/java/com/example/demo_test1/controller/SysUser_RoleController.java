package com.example.demo_test1.controller;

import com.example.demo_test1.mapper.SysRoleMapper;
import com.example.demo_test1.mapper.SysUserMapper;
import com.example.demo_test1.model.base.Result;
import com.example.demo_test1.model.system.SysMenu;
import com.example.demo_test1.model.vo.AssginRoleVo;
import com.example.demo_test1.servicee.SysMenuService;
import com.example.demo_test1.servicee.SysRoleService;
import com.example.demo_test1.servicee.SysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Api(tags = "用戶角色管理 ")
@RestController
@RequestMapping("/admin/system/user_Role")
public class SysUser_RoleController {

    private SysRoleService sysRoleService;
    private SysMenuService sysMenuService;
    private SysRoleMapper sysRoleMapper;
    private SysUserService sysUserService;
    private SysUserMapper sysUserMapper;

    @Autowired
    public SysUser_RoleController(SysRoleMapper sysRoleMapper,SysMenuService sysMenuService ,SysRoleService sysRoleService,SysUserService sysUserService, SysUserMapper sysUserMapper){
        this.sysUserService=sysUserService;
        this.sysUserMapper=sysUserMapper;
        this.sysRoleService=sysRoleService;
        this.sysRoleMapper=sysRoleMapper;
        this.sysMenuService=sysMenuService;
    }

    @ApiOperation("根据用户id查询角色")
    @GetMapping("/toAssign/{userId}")
    public Result selectStatusById(@PathVariable("userId") String id) {

        Map<String, Object> roleMapsByUserId = sysRoleService.getRoleMapsByUserId(id);
        return Result.ok(roleMapsByUserId);
    }

    @PreAuthorize("hasAuthority('bnt.sysUser.assignRole')")
    @ApiOperation("用户分配角色")
    @PostMapping("/doAssign")
    public Result doAssign(@RequestBody AssginRoleVo assginRoleVo) {
        sysRoleService.doAssign(assginRoleVo);
        return Result.ok();
    }
}
