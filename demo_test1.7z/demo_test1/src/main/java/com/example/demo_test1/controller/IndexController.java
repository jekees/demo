package com.example.demo_test1.controller;

import com.alibaba.fastjson2.JSON;
import com.example.demo_test1.jjwt.JwtHelper;
import com.example.demo_test1.mapper.SysUserMapper;
import com.example.demo_test1.model.base.Result;
import com.example.demo_test1.model.vo.LoginVo;
import com.example.demo_test1.servicee.SysUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Api("用户登录接口")
@RestController
@RequestMapping("/admin/system/index")
public class IndexController {
    @Autowired
    private SysUserService sysUserService;

    @Autowired
    private SysUserMapper sysUserMapper;


//    @ApiOperation("login接口")
//    @PostMapping("/login")
//    public Result info(@RequestBody LoginVo loginVo){
//        return Result.ok();
//    }
    @ApiOperation("登录获取权限接口")
    @GetMapping("/info")
    public Result info(HttpServletRequest request) {
        //获取请求头token字符串
        String token = request.getHeader("token");
        //从token字符串获取用户名称（id）
        String payload = JwtHelper.getPayloadByBase64(token);
        Map<String,Object> map= JSON.parseObject(payload,Map.class);
        String username=(String) map.get("username");
        System.out.println(username);
        //根据用户名称获取用户信息（基本信息 和 菜单权限 和 按钮权限数据）
        Map<String,Object> map2 = sysUserService.getUserInfo(username);
        return Result.ok(map2);

    }

}
