package com.example.demo_test1.servicee.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

import com.example.demo_test1.mapper.SysRoleMenuMapper;
import com.example.demo_test1.model.system.SysMenu;
import com.example.demo_test1.model.system.SysRole;
import com.example.demo_test1.model.system.SysRoleMenu;
import com.example.demo_test1.model.vo.AssginMenuVo;
import com.example.demo_test1.model.vo.AssginRoleVo;
import com.example.demo_test1.model.vo.RouterVo;
import com.example.demo_test1.servicee.SysMenuService;
import com.example.demo_test1.mapper.SysMenuMapper;
import com.example.demo_test1.util.G_Exception;
import com.example.demo_test1.util.MenuHelper;
import com.example.demo_test1.util.RouterHelper;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
* @author gys
* @description 针对表【sys_menu(菜单表)】的数据库操作Service实现
* @createDate 2023-05-06 13:56:08
*/
@Service
@Log4j2
public class SysMenuServiceImpl extends ServiceImpl<SysMenuMapper, SysMenu>
    implements SysMenuService{

    @Autowired
    SysRoleMenuMapper sysRoleMenuMapper;

    @Override
    public List<SysMenu> findNodes() {
        List<SysMenu> list = baseMapper.selectList(null);
        List<SysMenu> sysMenuList= MenuHelper.buildTree(list);
        return sysMenuList;
    }

    @Override
    public boolean removeMenuById(long id) {
        QueryWrapper<SysMenu> wrapper=new QueryWrapper<>();
        wrapper.eq("parent_id",id);
        Long count = baseMapper.selectCount(wrapper);
        if(count >0){
            throw  new G_Exception(201,"该菜单下还存在子菜单");
        }
        int i = baseMapper.deleteById(id);
        if(i!=0){
            return true;
        }
        return false;
    }

    @Override
    public List<SysMenu> getMenuByRoleId(String id) {
        QueryWrapper<SysMenu> queryWrapper=new QueryWrapper();
        queryWrapper.eq("status",1);
        List<SysMenu> sysMenuList = baseMapper.selectList(queryWrapper);

        QueryWrapper<SysRoleMenu> queryWrapper1=new QueryWrapper<>();
        queryWrapper1.eq("role_id",id);
        List<SysRoleMenu> sysRoleMenus = sysRoleMenuMapper.selectList(queryWrapper1);
        List<String> roleMenuIds=new ArrayList<>();

        sysRoleMenus.forEach(sysRoleMenu->{
            String menuId=sysRoleMenu.getMenuId();
            roleMenuIds.add(menuId);
        });
        sysMenuList.forEach(sysMenu -> {
            if(roleMenuIds.contains(sysMenu.getId())){

                sysMenu.setSelect(true);
                log.info("=="+sysMenu.isSelect());
            }else {
                sysMenu.setSelect(false);}
        });
        sysMenuList.forEach(sysMenu -> {
            log.info("=="+sysMenu.isSelect());
        });

        List<SysMenu> sysMenuList1 = MenuHelper.buildTree(sysMenuList);

        return sysMenuList1;
    }

    @Override
    public boolean toAssign(AssginMenuVo assginMenuVo) {
        QueryWrapper<SysRoleMenu> sysRoleMenuQueryWrapper=new QueryWrapper<>();
        sysRoleMenuQueryWrapper.eq("role_id",assginMenuVo.getRoleId());
        sysRoleMenuMapper.delete(sysRoleMenuQueryWrapper);

        List<String> menuIdList=assginMenuVo.getMenuIdList();
        menuIdList.forEach(menuId->{
            SysRoleMenu sysRoleMenu=new SysRoleMenu();
            sysRoleMenu.setMenuId(menuId);
            sysRoleMenu.setRoleId(assginMenuVo.getRoleId());
            sysRoleMenuMapper.insert(sysRoleMenu);
        });



        return false;
    }

    //根据userid查询菜单权限值
    @Override
    public List<RouterVo> getUserMenuList(String userId) {
        //admin是超级管理员，操作所有内容
        List<SysMenu> sysMenuList = null;
        //判断userid值是1代表超级管理员，查询所有权限数据
        if("1".equals(userId)) {
            QueryWrapper<SysMenu> wrapper = new QueryWrapper<>();
            wrapper.eq("status",1);
            wrapper.orderByAsc("sort_value");
            sysMenuList = baseMapper.selectList(wrapper);
        } else {
            //如果userid不是1，其他类型用户，查询这个用户权限
            sysMenuList = baseMapper.findMenuListUserId(userId);

        }

        //构建是树形结构
        List<SysMenu> sysMenuTreeList = MenuHelper.buildTree(sysMenuList);

        //转换成前端路由要求格式数据
        List<RouterVo> routerVoList = RouterHelper.buildRouters(sysMenuTreeList);
        return routerVoList;
    }

    //根据userid查询按钮权限值
    @Override
    public List<String> getUserButtonList(String userId) {
        List<SysMenu> sysMenuList = null;
        //判断是否管理员
        if("1".equals(userId)) {
            sysMenuList =
                    baseMapper.selectList(new QueryWrapper<SysMenu>().eq("status",1));
        } else {
            sysMenuList = baseMapper.findMenuListUserId(userId);
        }
        //sysMenuList遍历
        List<String> permissionList = new ArrayList<>();
        for (SysMenu sysMenu:sysMenuList) {
            // type=2
            if(sysMenu.getType()==2) {
                String perms = sysMenu.getPerms();
                permissionList.add(perms);
            }
        }
        return permissionList;
    }
}




