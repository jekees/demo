package com.example.demo_test1.servicee;

import com.example.demo_test1.model.system.SysUser;
import com.baomidou.mybatisplus.extension.service.IService;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
* @author gys
* @description 针对表【sys_user(用户表)】的数据库操作Service
* @createDate 2023-05-05 11:06:34
*/
@Component
public interface SysUserService extends IService<SysUser> {

    Map<String, Object> getUserInfo(String username);
}
