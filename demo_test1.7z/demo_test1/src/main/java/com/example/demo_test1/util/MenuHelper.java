package com.example.demo_test1.util;

import com.example.demo_test1.model.system.SysMenu;
import lombok.extern.log4j.Log4j2;

import java.util.ArrayList;
import java.util.List;

@Log4j2
public class MenuHelper {
    public static List<SysMenu> buildTree(List<SysMenu> list) {
         List<SysMenu> trees=new ArrayList<>();

         list.forEach(i->{
             if(i.getParentId()==0){
                 trees.add(findChildren(i,list));
             }
         });
         return trees;
    }

    private static SysMenu findChildren(SysMenu sysMenu, List<SysMenu> list) {
//        sysMenu.setChildren(new ArrayList<SysMenu>( ));

        list.forEach(i->{
            String id=sysMenu.getId();
            String parentId=i.getParentId( ).toString();

            if(id.equals(parentId)){
                if (sysMenu.getChildren()==null){
                    sysMenu.setChildren(new ArrayList<>());
                }
                sysMenu.getChildren().add(findChildren(i,list));
            }

        });
        return sysMenu;
    }
}
