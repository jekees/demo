package com.example.demo_test1.servicee;

import com.baomidou.mybatisplus.extension.service.IService;
import com.example.demo_test1.model.system.SysRoleMenu;

/**
* @author gys
* @description 针对表【sys_role_menu(角色菜单)】的数据库操作Service
* @createDate 2023-05-06 23:34:19
*/
public interface SysRoleMenuService extends IService<SysRoleMenu> {

}
