package com.example.demo_test1.controller;

import com.example.demo_test1.model.base.Result;
import com.example.demo_test1.model.system.SysMenu;
import com.example.demo_test1.model.vo.AssginMenuVo;
import com.example.demo_test1.model.vo.AssginRoleVo;
import com.example.demo_test1.servicee.SysMenuService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api
@RestController
@RequestMapping("/admin/system/sysMenu")
public class SysMenuController {
    private SysMenuService sysMenuService;

    @Autowired
    public SysMenuController(SysMenuService sysMenuService){
        this.sysMenuService=sysMenuService;
    }

    @PreAuthorize("hasAnyAuthority('bnt.sysMenu.delete','bnt.sysMenu.add','bnt.sysRole.assignAuth')")
    @ApiOperation("给角色分配菜单权限")
    @PostMapping("/doAssign")
    public Result toAssign(@RequestBody AssginMenuVo assginMenuVo){
        boolean b =sysMenuService.toAssign(assginMenuVo);
        return Result.ok(b);
    }
//    @PreAuthorize("hasAuthority('bnt.sysMenu.list')")
    @ApiOperation("根据角色获取菜单列表")
    @GetMapping("/toAssign/{roleId}")
    public Result findMenuByRoleId(@PathVariable String roleId){
        List<SysMenu> list=sysMenuService.getMenuByRoleId(roleId);
        return Result.ok(list);
    }
    @PreAuthorize("hasAuthority('bnt.sysMenu.list')")
    @ApiOperation("菜单列表")
    @GetMapping("/findNodes")
    public Result findNodes(){
        List<SysMenu> list=sysMenuService.findNodes();
        return Result.ok(list);
    }
    @PreAuthorize("hasAuthority('bnt.sysMenu.add')")
    @ApiOperation("添加菜单")
    @PostMapping("/save")
    public Result saveMenu(@RequestBody SysMenu sysMenu){
        boolean save = sysMenuService.save(sysMenu);
        if (save == false) {
            return Result.fail();
        }
        return Result.ok();
    }
    @PreAuthorize("hasAuthority('bnt.sysMenu.list')")
    @ApiOperation("根据id查询菜单")
    @GetMapping("/findMenuById/{id}")
    public Result findMenuById(@PathVariable("id") long id){
        SysMenu byId = sysMenuService.getById(id);
        return Result.ok(byId);
    }
    @PreAuthorize("hasAuthority('bnt.sysMenu.update')")
    @ApiOperation("修改菜单")
    @PutMapping("/updateMenuById")
    public Result findMenuById(@RequestBody SysMenu menu){
        boolean byId = sysMenuService.updateById(menu);
        if (byId == false) {
            return Result.fail();
        }
        return Result.ok();
    }
    @PreAuthorize("hasAuthority('bnt.sysMenu.remove')")
    @ApiOperation("根据id删除菜单")
    @DeleteMapping("/deleteMenuById/{id}")
    public Result deleteMenuById(@PathVariable("id") long id){

        boolean byId = sysMenuService.removeMenuById(id);

        if (byId == false) {
            return Result.fail();
        }
        return Result.ok();
    }


}
