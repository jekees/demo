package com.example.demo_test1.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo_test1.mapper.SysRoleMapper;
import com.example.demo_test1.model.base.Result;
import com.example.demo_test1.model.system.SysRole;
import com.example.demo_test1.model.vo.SysRoleQueryVo;
import com.example.demo_test1.servicee.SysRoleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.val;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Api(tags = "SysRoleController测试 ")
@RestController
@RequestMapping("/admin/system/sysRole")
public class SysRoleController {

    private SysRoleService sysRoleService;
    private SysRoleMapper sysRoleMapper;


    @Autowired
    public SysRoleController(SysRoleService sysRoleService, SysRoleMapper sysRoleMapper){
        this.sysRoleService=sysRoleService;
        this.sysRoleMapper=sysRoleMapper;
    }
    @PreAuthorize("hasAuthority('bnt.sysRole.list')")
    @ApiOperation("获取全部")
    @GetMapping("/findAll")
    public Result findAllRole(){
        List<SysRole> list = sysRoleService.list();
        return Result.ok(list);
    }
    @PreAuthorize("hasAuthority('bnt.sysRole.remove')")
    @ApiOperation("根据id逻辑删除")
    @DeleteMapping("/remove/{id}")
    public Result removeRoleById(@PathVariable("id") long id){
        boolean b = sysRoleService.removeById(id);
        if(b){
            return Result.ok();

        }
        else {
            return Result.fail();
        }

    }

    @PreAuthorize("hasAuthority('bnt.sysRole.list')")
    @ApiOperation("条件分页查询")
    @GetMapping("/{page}/{limit}")
    public Result findPageQueryRole(@PathVariable("page") Long page, @PathVariable("limit") Long limit,SysRoleQueryVo sysRoleQueryVo){
        Page<SysRole> page1=new Page<>(page,limit);
        IPage<SysRole> pageModel=sysRoleMapper.selectPage(page1,sysRoleQueryVo);
        return Result.ok(pageModel);
    }
    @PreAuthorize("hasAuthority('bnt.sysRole.add')")
    @ApiOperation("添加角色")
    @PostMapping("/save")
    public Result saveRole(@RequestBody SysRole role){
        boolean b = sysRoleService.save(role);
        if(b){
            return Result.ok();
        }
        else {
            return Result.fail();
        }
    }

    @PreAuthorize("hasAuthority('bnt.sysRole.update')")
    @ApiOperation("根据id修改")
    @PutMapping("/updateById")
    public Result updateRoleByID(@RequestBody SysRole role){

        boolean b = sysRoleService.updateById(role);
        if(b){
            return Result.ok();
        }
        else {
            return Result.fail();
        }
    }
    @PreAuthorize("hasAuthority('bnt.sysRole.list')")
    @ApiOperation("根据id查询")
    @GetMapping("/findById/{id}")
    public Result findRoleByID(@PathVariable long id){

        SysRole b = sysRoleService.getById(id);
        if(b!=null){
            return Result.ok(b);
        }
        else {
            return Result.fail();
        }
    }
    @PreAuthorize("hasAuthority('bnt.sysRole.remove')")
    @ApiOperation("根据id批量删除")
    @DeleteMapping("/removeByIds")
    public Result removeRolesByID(@RequestBody List<Long> ids){
        List list=new ArrayList();
        boolean b = sysRoleService.removeBatchByIds(ids);;
        return Result.ok();
    }

}
