package com.example.demo_test1.util;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

import java.nio.file.Path;
import java.util.ArrayList;

@Configuration
public class Swagger3Config {
    @Bean
    public Docket creatRestApi(){
        return new Docket(DocumentationType.OAS_30).apiInfo(createApiInfo()).enable(true)
                .select().paths(PathSelectors.ant("/**")).build()
                .groupName("");
    }

    @Bean
    public ApiInfo createApiInfo(){
        return new ApiInfo("标题","描述","版本号","http://www.java.vip",new Contact("gys","","1789961191@qq.com"),"Apache 2.0","协议url",new ArrayList<>());
    }
}
