package com.example.demo_test1.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo_test1.model.system.SysUser;
import com.example.demo_test1.model.vo.SysRoleQueryVo;
import com.example.demo_test1.model.vo.SysUserQueryVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
* @author gys
* @description 针对表【sys_user(用户表)】的数据库操作Mapper
* @createDate 2023-05-05 11:06:34
* @Entity com.example.demo_test1.model.base.SysUser
*/
@Mapper
public interface SysUserMapper extends BaseMapper<SysUser> {
    IPage<SysUser> selectPage(Page page1,@Param("vo") SysUserQueryVo sysUserQueryVo);

    SysUser selectUserByUsername(String username);

    Integer updateUserPasswordByUsername(@Param("password") String newPassword, @Param("username") String username);
}




