package com.example.demo_test1.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class G_Exception extends RuntimeException
{
    private Integer code;
    private  String msg;
}
