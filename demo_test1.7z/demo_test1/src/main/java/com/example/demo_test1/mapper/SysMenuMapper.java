package com.example.demo_test1.mapper;

import com.example.demo_test1.model.system.SysMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
* @author gys
* @description 针对表【sys_menu(菜单表)】的数据库操作Mapper
* @createDate 2023-05-06 13:56:07
* @Entity generator.domain.SysMenu
*/
@Mapper
public interface SysMenuMapper extends BaseMapper<SysMenu> {

    List<SysMenu> findMenuListUserId(String userId);
}




