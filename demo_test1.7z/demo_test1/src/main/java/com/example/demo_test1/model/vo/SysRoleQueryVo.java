package com.example.demo_test1.model.vo;


import java.io.Serializable;

public class SysRoleQueryVo implements Serializable {
    private static final long serialVersionUID = 1L;

    private String roleName;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

}
